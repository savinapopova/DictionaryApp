package com.dictionaryapp.service;

public interface LanguageService {
    void seed();
}
